Starting point for NFC tutorial
==================================

 * Basic project setup
 * Android manifest permissions 
 * Library imports and some empty methods 
 * Added title id in main.xml
 
